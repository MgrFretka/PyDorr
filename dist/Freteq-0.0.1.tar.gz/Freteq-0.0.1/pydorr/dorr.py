from .extension import commands, wake
from client import *

client = Client(code='00000', echo="n")

class Dorr:
    """Zebranie wszystkich importów z plików zawierających komendy do package'a"""

    def __init__(self):
        pass

    def DorrClient(self, code: client.clientcodes):
        pass