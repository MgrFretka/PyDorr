Nic specjalnego
* chyba